const express = require('express');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── HEALTH ──
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'Project HorsePillow' });
});

// ── TODAY ──
app.get('/api/today', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const events = db.prepare(`
    SELECT * FROM events 
    WHERE date = ? 
    ORDER BY time ASC
  `).all(today);
  res.json(events);
});

// ── UPCOMING ──
app.get('/api/upcoming', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const events = db.prepare(`
    SELECT * FROM events 
    WHERE date > ? 
    ORDER BY date ASC, time ASC
    LIMIT 5
  `).all(today);
  res.json(events);
});

// ── EVENTS CRUD ──
app.get('/api/events', (req, res) => {
  const events = db.prepare('SELECT * FROM events ORDER BY date ASC, time ASC').all();
  res.json(events);
});

app.post('/api/events', (req, res) => {
  const { title, date, time, person, note, type } = req.body;
  const result = db.prepare(`
    INSERT INTO events (title, date, time, person, note, type)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title, date, time || null, person || 'family', note || null, type || 'event');
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.delete('/api/events/:id', (req, res) => {
  db.prepare('DELETE FROM events WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── TASKS ──
app.get('/api/tasks', (req, res) => {
  const tasks = db.prepare('SELECT * FROM tasks WHERE done = 0 ORDER BY created_at DESC').all();
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const { title, person, due_date, note } = req.body;
  const result = db.prepare(`
    INSERT INTO tasks (title, person, due_date, note)
    VALUES (?, ?, ?, ?)
  `).run(title, person || 'jeff', due_date || null, note || null);
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.patch('/api/tasks/:id/done', (req, res) => {
  db.prepare('UPDATE tasks SET done = 1 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── DISPATCHES ──
app.get('/api/dispatches', (req, res) => {
  const dispatches = db.prepare(`
    SELECT * FROM dispatches 
    WHERE to_person = 'jeff' AND done = 0 
    ORDER BY created_at DESC
  `).all();
  res.json(dispatches);
});

app.post('/api/dispatches', (req, res) => {
  const { title, note, type, from_person, to_person } = req.body;
  const result = db.prepare(`
    INSERT INTO dispatches (title, note, type, from_person, to_person)
    VALUES (?, ?, ?, ?, ?)
  `).run(title, note || null, type || 'task', from_person || 'jenn', to_person || 'jeff');
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.patch('/api/dispatches/:id/done', (req, res) => {
  db.prepare('UPDATE dispatches SET done = 1 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── DROP ZONE ──
app.post('/api/drop', (req, res) => {
  const { raw } = req.body;
  const result = db.prepare(`
    INSERT INTO drops (raw, status)
    VALUES (?, 'pending')
  `).run(raw);
  res.json({ id: result.lastInsertRowid, raw, status: 'pending', message: "Got it. HorsePillow is on it." });
});

app.get('/api/drops', (req, res) => {
  const drops = db.prepare('SELECT * FROM drops ORDER BY created_at DESC LIMIT 20').all();
  res.json(drops);
});

// ── FIRESIDE ──
app.get('/api/fireside', (req, res) => {
  const items = db.prepare('SELECT * FROM fireside WHERE done = 0 ORDER BY created_at DESC').all();
  res.json(items);
});

app.post('/api/fireside', (req, res) => {
  const { title, note, added_by, scheduled_date } = req.body;
  const result = db.prepare(`
    INSERT INTO fireside (title, note, added_by, scheduled_date)
    VALUES (?, ?, ?, ?)
  `).run(title, note || null, added_by || 'jeff', scheduled_date || null);
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.patch('/api/fireside/:id/done', (req, res) => {
  db.prepare('UPDATE fireside SET done = 1 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── WATCH LIST ──
app.get('/api/watchlist', (req, res) => {
  const shows = db.prepare('SELECT * FROM watchlist ORDER BY status ASC, updated_at DESC').all();
  res.json(shows);
});

app.post('/api/watchlist', (req, res) => {
  const { title, platform, season, episode, status, note } = req.body;
  const result = db.prepare(`
    INSERT INTO watchlist (title, platform, season, episode, status, note)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title, platform || null, season || 1, episode || 1, status || 'watching', note || null);
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.patch('/api/watchlist/:id', (req, res) => {
  const { season, episode, status, note } = req.body;
  db.prepare(`
    UPDATE watchlist SET season=?, episode=?, status=?, note=?, updated_at=CURRENT_TIMESTAMP
    WHERE id=?
  `).run(season, episode, status, note, req.params.id);
  res.json({ success: true });
});

// ── FOOD LOTTERY ──
app.get('/api/food', (req, res) => {
  const places = db.prepare('SELECT * FROM food_places WHERE active = 1 ORDER BY name ASC').all();
  res.json(places);
});

app.get('/api/food/spin', (req, res) => {
  const places = db.prepare('SELECT * FROM food_places WHERE active = 1').all();
  if (!places.length) return res.json({ error: 'No places added yet' });
  const pick = places[Math.floor(Math.random() * places.length)];
  res.json(pick);
});

app.post('/api/food', (req, res) => {
  const { name, type } = req.body;
  const result = db.prepare('INSERT INTO food_places (name, type) VALUES (?, ?)').run(name, type || 'restaurant');
  res.json({ id: result.lastInsertRowid, ...req.body });
});

// ── SCOUT MOMENT ──
app.get('/api/scout', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const todayEvents = db.prepare('SELECT * FROM events WHERE date = ?').all(today);
  const pendingDispatches = db.prepare("SELECT COUNT(*) as count FROM dispatches WHERE to_person='jeff' AND done=0").get();
  const pendingTasks = db.prepare("SELECT COUNT(*) as count FROM tasks WHERE person='jeff' AND done=0").get();

  let message = "You're all clear today, Commander. Good day to get ahead.";
  let type = 'clear';

  if (pendingDispatches.count > 0) {
    message = `Jenn sent you ${pendingDispatches.count} dispatch${pendingDispatches.count > 1 ? 'es' : ''}. Don't leave her hanging.`;
    type = 'dispatch';
  } else if (todayEvents.length > 0) {
    const next = todayEvents[0];
    message = `${next.title} is on the board today${next.time ? ' at ' + formatTime(next.time) : ''}. You've got this.`;
    type = 'event';
  } else if (pendingTasks.count > 0) {
    message = `${pendingTasks.count} task${pendingTasks.count > 1 ? 's' : ''} waiting on you. Small steps, big results.`;
    type = 'task';
  }

  res.json({ message, type });
});

function formatTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':');
  const hour = parseInt(h);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const h12 = hour % 12 || 12;
  return `${h12}:${m} ${ampm}`;
}

app.listen(PORT, () => {
  console.log(`🐴 Project HorsePillow running on port ${PORT}`);
});
